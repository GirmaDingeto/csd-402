/*
 *  CSD402-300O, Module 3.2 Assignment ,03/05/2026
 */
package com.mycompany.pyramidpattern;
/**
 *
 * Girma Dingeto
 */

public class PyramidPattern {

    public static void main(String[] args) {
        int rows =7;//Total number of rows in the pattern
        
        for(int i=0; i<rows; i++){
            
            
        // 1. Print leading space for alignmentto center the pyramid
            for (int j=0; j < (rows-i-1)*2; j++){
                System.out.print(" ");
            
        }
           
        // 2. displaying Inner loop for increasing powers of 2 (1 to 2^i)
            for(int j =0; j<=i; j++){
                System.out.print((int)Math.pow(2, j)+" ");
            
        }
            
             
        //3.Inner loop for decreasing powers of 2(2^(i-1) down to 1)
            for (int j=i-1; j>=0; j--){
                System.out.print((int)Math.pow(2, j)+" ");
            
            }
            // 4. Print the trailing '@' character
            //The number of space before'@' ensures its alignment at the end
            for (int j=1; j<=(rows-i-1)*2;j++){
                System.out.print(" ");
            }
          
        System.out.println(("\t@"));
           
        
        }
        
        
    }
}
