/*
 *CSD402-300O, Module2.2 Assignment
 */

package com.mycompany.rockscissorspaperassignment;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * Girma Dingeto
 */
public class RockScissorsPaperAssignment {

    public static void main(String[] args){
       Scanner scanner = new Scanner(System.in);
       Random random=new Random();
       boolean playAgain=true;
       
       System.out.println("Welcome to Rock-Paper-Scissors!");
       System.out.println("Rules:1=Rock, 2=Paper, 3=Scissors");
        
       while(playAgain){
           //1.Generate computer selection(1,2,or 3)
           int computerSelection = random.nextInt(3)+1;
           //2.Prompt user for selection
           System.out.print("\nEnter your choice(1,2,3):");
           int userSelection=scanner.nextInt();
           
           //3.Display Choice clearly
           System.out.println("Computer chose:"+getChoiceName(computerSelection));
           System.out.println("You chose:" + getChoiceName(userSelection));
           
           //4.Determine and display results
           if (userSelection == computerSelection ){
               System.out.println("Result: It's a tie!");
           } else if ((userSelection==1 && computerSelection==3) ||
                   (userSelection == 2 && computerSelection == 1)||
                   (userSelection == 3 && computerSelection == 2)){
               System.out.println("Result:You Win!");
               
           }else if (userSelection < 1|| userSelection > 3){
           System.out.println("Result: Invalid selection.");
           }else {
               System.out.println("Result:Computer wins!");
           }
           //Ask user to play again
           System.out.print("\nDo you want to play again?(1 for Yes, 0 for No):");
           int response=scanner.nextInt();
           if(response==0){
               playAgain=false;
           }
               
         }
        System.out.println("Thanks for playing!");
        scanner.close();
      }
    //Helper method to convert numbers to clear names
    public static String getChoiceName(int choice){
    
        switch(choice){
            case 1: return "Rock";
            case 2: return "Paper";
            case 3: return "Scissors";
            default:return "invalid";
        }
        
    }
    
    
 }
