/*
 * Girma Dingeto
 * CSD402-300O Module 1.3 Assignment
 */

package waterheater;
 
import java.util.Scanner;
public class WaterHeater {

    public static void main(String[] args) {
        
        //Create a Scanner object for user input
        Scanner input = new Scanner(System.in);
        
        // Prompt the user to enter the amount of water in killograms
        System.out.print("Enter the amount of water in Killograms:");
        double waterMass = input.nextDouble();
        
        // Promot the user to enter the initial temperature in degree Celsius
        System.out.print("Enter the initial temperature in degree Celsius:");
        double initialTemperature = input.nextDouble();
        
        // Promot the user to enter the final temperature in degree Celsius
        System.out.print("Enter the final temperature in degree Celsius:");
        double finalTemperature = input.nextDouble();
        
        // Calculate the energy (Q) using the formula:
        //Q = waterMass*(finalTemperature - initialTemperature)*4184
        double energyNeeded = waterMass*(finalTemperature - initialTemperature)*4184;
        
        // Display the result
        System.out.println("The energy needed is" + energyNeeded + "Joules");
        
        // Close the scanner
        input.close();
    }
}
